package Professor;

import java.util.Objects;
import javax.swing.JOptionPane;

public class Profesor {
    private String nombre;
    private Integer codigoDeProfessor;

    public Profesor(String nombre, Integer codigoDeProfessor) {
        this.nombre = nombre;
        this.codigoDeProfessor = codigoDeProfessor;
    }


    
    
    public int hashCode() {
        return Objects.hash(codigoDeProfessor);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getCodigoDeProfessor() {
        return codigoDeProfessor;
    }

    public void setCodigoDeProfessor(Integer codigoDoProfessor) {
        this.codigoDeProfessor = codigoDoProfessor;
    }

    
}
