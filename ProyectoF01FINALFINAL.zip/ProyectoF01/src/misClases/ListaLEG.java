package misClases;

import java.util.ArrayList;
import java.util.Random;
import miMatricula.claseMatricula;

public class ListaLEG<E extends claseMatricula> {
    private NodoLEG<E> primero;
    private int talla; 

    public ListaLEG() {
        this.primero=null;
        this.talla=0;
    }
    public NodoLEG<E> getPrimero() {
        return primero;
    }
    public int getTalla() {
        return talla;
    }
    public void insertarAlInicio(E x){        
        NodoLEG<E> nuevo=new NodoLEG<>(x);        
        nuevo.setSiguiente(primero);        
        primero = nuevo;
        talla++;
    }
    public void insertarAlFinal(E x){        
        NodoLEG<E> nuevo=new NodoLEG<>(x);    
        NodoLEG<E> aux=primero;
        
        if(primero ==null){
            primero=nuevo;
        }else{
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        talla++;       
    }
    public void nuevaMatricula(E x){
        if(talla==0)
        {
            insertarAlInicio(x);
        }
        else
        {
            Random r = new Random();
            int k = r.nextInt(talla+1)+1;
            NodoLEG<E> aux = primero;
            if(k==talla)
            {
                insertarAlFinal(x);
            }
            else
            {
                int cont=1;
                while(aux!=null && cont<k)
                {
                    aux=aux.getSiguiente();
                    cont++;
                }
                NodoLEG<E> siguiente = aux.getSiguiente();
                NodoLEG<E> nuevo = new NodoLEG<E>(x);
                aux.setSiguiente(nuevo);
                nuevo.setSiguiente(siguiente);
            }
        }
        talla++;
    }
    public ArrayList<E> listaMatricula(){
        ArrayList<E> matricula = new ArrayList<E>();
        NodoLEG<E> aux = primero;
        while(aux!=null){
            matricula.add(aux.getDato());
            aux=aux.getSiguiente();
        }
        return matricula;
    }
}
