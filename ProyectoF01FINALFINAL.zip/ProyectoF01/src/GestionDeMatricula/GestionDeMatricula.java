package GestionDeMatricula;

import Aluno.Aluno;
import Curso.Curso;
import Matricula.Matricula;
import Professor.Profesor;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class GestionDeMatricula {

    private List<Aluno> listaDeAlunos = new ArrayList<Aluno>();
    private List<Profesor> listaDeProfesor = new ArrayList<Profesor>();
    private List<Curso> listaDeCurso = new ArrayList<Curso>();
    private List<Matricula> listaDeMatricula = new ArrayList<Matricula>();


    public void registrarCurso(String nombre, Integer codigoDeCurso) {
        Curso curso = new Curso(nombre, codigoDeCurso);
        listaDeCurso.add(curso);
        
        JOptionPane.showMessageDialog(null, "El curso " + curso.getNombre() + " de codigo " + curso.getCodigoDeCurso() + " se ha registrado");

    }

    public void BorrarCurso(Integer codCurso) {
        for (Curso curso : listaDeCurso) {
            if (curso.getCodigoDeCurso() == codCurso) {
                listaDeCurso.remove(codCurso);
                System.out.println("EL curso " + curso.getNombre() + " " + curso.getCodigoDeCurso() + " Se ha removido");
                JOptionPane.showMessageDialog(null, "El curso " + curso.getNombre() + " de codigo " + curso.getCodigoDeCurso() + " se ha borrado");
            }

        }

    }

    public void registrarProfessor(String nombre, Integer codProfessor) {
        
        Profesor profesor = new Profesor(nombre, codProfessor);
        listaDeProfesor.add(profesor);
        JOptionPane.showMessageDialog(null, "El Profesor " + profesor.getNombre() + " Ha sido registrado");
    }


    public void BorrarProfessor(Integer codProfessor) {
        for (Profesor professor : listaDeProfesor) {
            if (professor.getCodigoDeProfessor() == codProfessor) {
                listaDeProfesor.remove(professor);
                JOptionPane.showMessageDialog(null, "El profesor" + professor.getNombre() + " de codigo " + professor.getCodigoDeProfessor() + " Se ha removido con exito");

            }
        }
    }


    public void matricularAluno(String nombre, Integer codAluno) {
        Aluno aluno = new Aluno(nombre, codAluno);
        listaDeAlunos.add(aluno);
        JOptionPane.showMessageDialog(null, "Se ha matriculado a " + aluno.getNombre() + " con exito!");

    }


    public Aluno buscarAlunoPorCodigo(Integer codAluno) {
        for (Aluno aluno : listaDeAlunos) {
            if (aluno.getCodAluno() == codAluno) {
                JOptionPane.showMessageDialog(null, "Se ha encontrado a " + aluno.getNombre() + " de codido " + aluno.getCodAluno() + " con exito");
                return aluno;
            }
        }
        return null;
    }


    public Curso buscarCursoPorCodigo(Integer codCurso) {
        for (Curso curso : listaDeCurso) {
            if (curso.getCodigoDeCurso().equals(codCurso)) {
            
                JOptionPane.showMessageDialog(null, "Se a encontrado el curso " + curso.getNombre() + " de codigo " + curso.getCodigoDeCurso() + " con exito.");
                return curso;
            }

        }
        return null;
    }


    public Profesor buscarProfessorPorCodigo(Integer codProfessor) {
        for (Profesor professor : listaDeProfesor) {
            if (professor.getCodigoDeProfessor().equals(codProfessor)) {
                JOptionPane.showMessageDialog(null, "Se a encontrado al profesor " + professor.getNombre() + " de codigo " + professor.getCodigoDeProfessor() + " con xito!");
                return professor;
            }
        }
        return null;
    }



    public void matricularAlunoEnCurso(Integer codAluno, Integer codCurso) {
        Aluno aluno = buscarAlunoPorCodigo(codAluno);
        Curso curso = buscarCursoPorCodigo(codCurso);
        System.out.println(curso.getCodigoDeCurso());
        if (curso.verificarAlunoMatriculado(aluno)) {
            JOptionPane.showMessageDialog(null, "El alumno de codigo " + codAluno + " ya se encuentra matriculado en el curso de codigo " + codCurso );
        } else {
            curso.aniadiAlumno(aluno);
            Matricula matricula = new Matricula(aluno, curso);
            listaDeMatricula.add(matricula);
            JOptionPane.showMessageDialog(null, "El alumno " + aluno.getNombre() + " Se ha registrado en el curso " + curso.getNombre());

        }
    }


    public void asignarProfessores(Integer codCurso, Integer codigoDeProfessor) {

        Curso curso = buscarCursoPorCodigo(codCurso);
        curso.setProfesor(buscarProfessorPorCodigo(codigoDeProfessor));
        
        JOptionPane.showMessageDialog(null, "El profesor de codigo " + codigoDeProfessor + " Ha sido registrado al curso");
    }

    public void alunoConsultaCurso(Integer codAlunoDigitado) {
        int matriculado = 0;
        for (Matricula unaMatricula : listaDeMatricula) {
            if (unaMatricula.getAluno().getCodAluno() == codAlunoDigitado) {
                String NombreDelCursoMatriculado = unaMatricula.getCurso().getNombre();
                JOptionPane.showMessageDialog(null, "El alumno se encuentra matriculado en "+NombreDelCursoMatriculado);
                matriculado++;
            }

        }
        if (matriculado == 0) {
           JOptionPane.showMessageDialog(null, "El alumno no se encuentra matriculado");
        }

    }


    public List<Aluno> getListaDeAlunos() {
        return listaDeAlunos;
    }

    public void setListaDeAlunos(List<Aluno> listaDeAlunos) {
        this.listaDeAlunos = listaDeAlunos;
    }

    public List<Profesor> getListaDeProfesor() {
        return listaDeProfesor;
    }

    public void setListaDeProfesor(List<Profesor> listaDeProfessor) {
        this.listaDeProfesor = listaDeProfessor;
    }

    public List<Curso> getListaDeCurso() {
        return listaDeCurso;
    }

    public void setListaDeCurso(List<Curso> listaDeCurso) {
        this.listaDeCurso = listaDeCurso;
    }

    public List<Matricula> getListaDeMatricula() {
        return listaDeMatricula;
    }

    public void setListaDeMatricula(List<Matricula> listaDeMatricula) {
        this.listaDeMatricula = listaDeMatricula;
    }
}
