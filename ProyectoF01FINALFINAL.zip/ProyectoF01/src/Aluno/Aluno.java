package Aluno;

import Curso.Curso;

import java.util.Objects;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Aluno {
    private String nombre;
    private int codAluno;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Aluno aluno = (Aluno) o;
        return codAluno == aluno.codAluno;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codAluno);
    }

    public String consultarCursoMatriculado;


    public Aluno(String nombre, int codAluno) {
        this.nombre = nombre;
        this.codAluno = codAluno;
        this.consultarCursoMatriculado = consultarCursoMatriculado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }





    

    public int getCodAluno() {
        return codAluno;
    }

    public void setCodAluno(int codAluno) {
        this.codAluno = codAluno;
    }

    public String getConsultarCursoMatriculado() {
        return consultarCursoMatriculado;
    }

    public void setConsultarCursoMatriculado(String consultarCursoMatriculado) {
        this.consultarCursoMatriculado = consultarCursoMatriculado;

    }

}
