package Curso;

import Aluno.Aluno;
import Professor.Profesor;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Curso {
    public boolean contains;
    private String Nombre;
    private Integer codigoDeCurso;
    private Profesor profesor;
    private List<Aluno> listaDeAlunosMatriculados = new ArrayList<Aluno>();

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Curso curso = (Curso) o;
        return Objects.equals(codigoDeCurso, curso.codigoDeCurso);
    }

    public int hashCode() {
        return Objects.hash(codigoDeCurso);
    }

    public Curso(String nombre, Integer codigoDeCurso) {
        this.Nombre = nombre;
        this.codigoDeCurso = codigoDeCurso;
    }

    public Boolean verificarAlunoMatriculado(Aluno aluno) {
        Boolean retorno = false;
        for (Aluno umAluno : listaDeAlunosMatriculados) {
            if (umAluno.equals(aluno)) {
                System.out.println("aluno ja matriculado.");
                retorno = true;
            }

        }
        return retorno;
    }

    public Boolean aniadiAlumno(Aluno aluno) {
        if (!verificarAlunoMatriculado(aluno)) {
            
            listaDeAlunosMatriculados.add(aluno);
            System.out.println(aluno.getNombre() + " Ha sido matriculado para la temporada " + " " + Nombre);
            System.out.println("===============================================================================");
                return true;

        } else {
            System.out.println("El alumno " +aluno.getNombre()+" No se puede matricular");
            System.out.println("===============================================================================");
        }
        return false;
    }


        public void RemoverAlumno (Aluno aluno){
            listaDeAlunosMatriculados.remove(aluno);
            System.out.println("El alumno " + aluno.getNombre() + " Ha sido removido");
            System.out.println("===============================================================================");


        }

    public boolean isContains() {
        return contains;
    }

    public void setContains(boolean contains) {
        this.contains = contains;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String AnioEscolar) {
        this.Nombre = AnioEscolar;
    }

    public Integer getCodigoDeCurso() {
        return codigoDeCurso;
    }

    public void setCodigoDeCurso(Integer codigoDeCurso) {
        this.codigoDeCurso = codigoDeCurso;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public List<Aluno> getListaDeAlunosMatriculados() {
        return listaDeAlunosMatriculados;
    }

    public void setListaDeAlunosMatriculados(List<Aluno> listaDeAlunosMatriculados) {
        this.listaDeAlunosMatriculados = listaDeAlunosMatriculados;
    }




    }
