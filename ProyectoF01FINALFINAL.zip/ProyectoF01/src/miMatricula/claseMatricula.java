package miMatricula;

public class claseMatricula {
    
    private String nombre;
    private String apellido;
    private int edad;
    private String año;
    private String modalidad;
    private String puesto;
    private float monto;

    public claseMatricula(String nombre, String apellido, int edad, 
            String año, String modalidad, String puesto, float monto) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.año = año;
        this.modalidad = modalidad;
        this.puesto = puesto;
        this.monto = monto;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getAño() {
        return año;
    }
    public void setAño(String año) {
        this.año = año;
    }
    public String getModalidad() {
        return modalidad;
    }
    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }
    public String getPuesto() {
        return puesto;
    }
    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
    public float getMonto() {
        return monto;
    }
    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    public void asignarCosto(){
        if(puesto.equalsIgnoreCase("Superior"))
        {
            modalidad = "Beca";
            monto = 0.00f;
        }
        if(puesto == "Medio")
        {
            modalidad = "Normal";
            if(año == "Primero" || año == "Segundo" || año == "Tercero" || año == "Cuarto" || año == "Quinto" || año == "Sexto")
            {
                monto = 600.00f;
            }
            if(año == "Septimo" || año == "Octavo" || año == "Noveno" || año == "Décimo" || año == "Undécimo")
            {
                monto = 800.00f;
            }
        }
        if (puesto == "Bajo")
        {
            modalidad = "Normal";
            if(año == "Primero" || año == "Segundo" || año == "Tercero" || año == "Cuarto" || año == "Quinto" || año == "Sexto")
            {
                monto = 700.00f;
            }
            if(año == "Septimo" || año == "Octavo" || año == "Noveno" || año == "Décimo" || año == "Undécimo")
            {
                monto = 900.00f;
            }
        }
    }
}
