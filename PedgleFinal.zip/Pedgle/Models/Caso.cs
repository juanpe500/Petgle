using System.ComponentModel.DataAnnotations;
namespace Pedgle.Models
{
    public class Caso
    {

        public int Id { get; set; }
        [Required]
        public string CasoText { get; set; }
        

        


    }
}