using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Pedgle.Models
{
    public class MascotaContext : IdentityDbContext
    {
        
        public DbSet<Mascota> Mascotas { get; set; }

        public MascotaContext(DbContextOptions<MascotaContext> options) : base(options) { }

    }
}