using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
namespace Pedgle.Models
{
    public class CasoContext : IdentityDbContext
    {
        public DbSet<Caso> Casos { get; set; }

        public CasoContext(DbContextOptions<CasoContext> options) : base(options) { }
    }
}


