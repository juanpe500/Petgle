using System.Linq;
using Pedgle.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Pedgle.Controllers
{
    
    public class MascotaController : Controller
    {
        
        
        private MascotaContext _context { get; }

        public MascotaController(MascotaContext context) {
            _context = context;
        }
  

        public IActionResult Listar()
        {
            //Aqui se muestran todas las mascotas por filtros
            var mascotas = _context.Mascotas.ToList();

            return View(mascotas);
        }
        public IActionResult Casos()
        {
            
            return View();
        }
        //Unable to create an object of type 'CasoContext'. For the different patterns supported at design time
        public IActionResult Registrar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Registrar(Mascota m)
        {
            if (ModelState.IsValid) {
                _context.Mascotas.Add(m);
                _context.SaveChanges();

                return RedirectToAction("Listar");
            }

            return View(m);
        }

        public IActionResult Perfil(int id)
        {
            var m = _context.Mascotas.FirstOrDefault(x => x.Id == id);

            if (m == null) {
                return NotFound();
            }

            return View(m);
        }

        [HttpPost]
        public IActionResult Actualizar(Mascota m)
        {
            if (ModelState.IsValid) {
                var mascotaBd = _context.Mascotas.Find(m.Id);

                mascotaBd.Estado = m.Estado;
                mascotaBd.Nombre = m.Nombre;

                mascotaBd.Foto = m.Foto;

                _context.SaveChanges();

                return RedirectToAction("Listar");
            }

            return View(m);
        }

        public IActionResult Borrar(int id)
        {
            var m = _context.Mascotas.FirstOrDefault(x => x.Id == id);

            if (m != null) {
                _context.Mascotas.Remove(m);
                _context.SaveChanges();
            }

            return RedirectToAction("Listar");
        }

    }
}