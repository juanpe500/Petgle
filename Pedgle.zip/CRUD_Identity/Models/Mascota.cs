using System.ComponentModel.DataAnnotations;

namespace CRUD_Identity.Models
{
    public class Mascota
    {
        public int Id { get; set; }
        [Required]
        public string Estado { get; set; }
        public string Nombre { get; set; }

        [Required]
        public string Especie { get; set; }

        public string Raza { get; set; }
        [Required]
        public string Foto { get; set; }

        [Required]
        public string Fecha { get; set; }
        [Required]
        public string Ubicacion { get; set; }

        [Required]
        public string TelefonoConctacto { get; set; }
        [Required]
        public string Descripcion { get; set; }


    }
}