using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CRUD_Identity.Models
{
    public class MascotasContext: IdentityDbContext
    {
        public DbSet<Mascota> Mascotas { get; set; }

        public MascotasContext(DbContextOptions<MascotasContext> options) : base(options) { }
    }
}