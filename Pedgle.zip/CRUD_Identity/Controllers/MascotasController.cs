using CRUD_Identity.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUD_Identity.Controllers
{
    public class MascotasController : Controller
    {
        private MascotasContext _context { get; }
        public IActionResult Perdidas(){
            return View();
        }
        public IActionResult Encontradas(){
            return View();
        }
        public IActionResult Callejeras(){
            return View();
        }
        public IActionResult EnAdopcion(){
            return View();
        }
        public IActionResult Retornadas(){
            return View();
        }
        public IActionResult RegistrarMascota(){
            return View();
        }
        [HttpPost]
        public IActionResult RegistrarMascota(Mascota m){
            if (ModelState.IsValid) {
                _context.Mascotas.Add(m);
                _context.SaveChanges();

                return RedirectToAction("Listar");
            }

            return View(m);
        }
    }
}